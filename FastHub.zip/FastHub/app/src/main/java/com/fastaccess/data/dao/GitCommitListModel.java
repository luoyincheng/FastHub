package com.fastaccess.data.dao;

import java.util.ArrayList;

/**
 * Created by Kosh on 12 Feb 2017, 12:14 AM
 */

public class GitCommitListModel extends ArrayList<GitCommitModel> {}
