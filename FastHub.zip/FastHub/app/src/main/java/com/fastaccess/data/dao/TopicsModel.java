package com.fastaccess.data.dao;

import java.util.ArrayList;

/**
 * Created by Kosh on 09 May 2017, 7:52 PM
 */

public class TopicsModel extends ArrayList<String> {}
